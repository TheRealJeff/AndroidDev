package com.example.gradeviewer;

import android.os.Bundle;
import androidx.appcombat.widget.Toolbar;
import androidx.appcompat.app.AppCompatActivity;


public class gradeActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grade_viewer);

        setupUI();
    }

    protected void setupUI(){
        Toolbar toolbar_gradeActivity = (Toolbar) findViewById(R.id.toolbar_gradeActivity);
        setSupportActionBar(toolbar_gradeActivity);
    }
}